// netlify/functions/create-checkout.js
// Cette fonction tourne côté serveur — votre clé Stripe est invisible pour les visiteurs

const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

const PRODUITS = {
  "100g": {
    name: "Poudre de Sidr pure — 100g",
    description: "Format Découverte · Idéal pour commencer votre rituel Sidr",
    price: 1290, // en centimes (= 12,90 €)
    image: "https://VOTRE_SITE.netlify.app/images/sidr-100g.jpg",
  },
  "250g": {
    name: "Poudre de Sidr premium — 250g",
    description: "Format Essentiel · Notre plus populaire, usage régulier",
    price: 2690,
    image: "https://VOTRE_SITE.netlify.app/images/sidr-250g.jpg",
  },
  "500g": {
    name: "Poudre de Sidr pure — 500g",
    description: "Format Famille · Économique et généreux",
    price: 4490,
    image: "https://VOTRE_SITE.netlify.app/images/sidr-500g.jpg",
  },
};

exports.handler = async (event) => {
  // Sécurité : on accepte seulement les POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { format, quantity = 1 } = JSON.parse(event.body);
    const produit = PRODUITS[format];

    if (!produit) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Format inconnu : " + format }),
      };
    }

    const siteUrl = process.env.SITE_URL || "http://localhost:8888";

    // Création de la session Stripe Checkout
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      locale: "fr",
      line_items: [
        {
          price_data: {
            currency: "eur",
            product_data: {
              name: produit.name,
              description: produit.description,
              // images: [produit.image], // Décommentez quand vous avez de vraies images
            },
            unit_amount: produit.price,
          },
          quantity: Math.min(Math.max(parseInt(quantity), 1), 10),
        },
      ],
      mode: "payment",
      shipping_address_collection: {
        allowed_countries: ["FR", "BE", "CH", "MA", "DZ", "TN", "LU"],
      },
      shipping_options: [
        {
          shipping_rate_data: {
            type: "fixed_amount",
            fixed_amount: { amount: 0, currency: "eur" },
            display_name: "Livraison offerte",
            delivery_estimate: {
              minimum: { unit: "business_day", value: 3 },
              maximum: { unit: "business_day", value: 5 },
            },
          },
        },
      ],
      success_url: siteUrl + "/merci.html?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: siteUrl + "/#produits",
      metadata: { format, quantity: String(quantity) },
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: session.url }),
    };
  } catch (err) {
    console.error("Stripe error:", err.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Erreur lors de la création du paiement." }),
    };
  }
};
